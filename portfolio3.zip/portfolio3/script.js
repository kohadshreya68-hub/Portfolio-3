// ---------- COMMON HELPER ----------
function showMessage(text, type = "success") {
  const msg = document.getElementById("formMessage");
  msg.textContent = text;
  msg.className = type;
}

// ---------- DARK MODE ----------
const darkModeBtn = document.getElementById("darkModeBtn");

function toggleDarkMode() {
  document.body.classList.toggle("dark-mode");
  localStorage.setItem(
    "darkMode",
    document.body.classList.contains("dark-mode")
  );
}

darkModeBtn.addEventListener("click", toggleDarkMode);

// load saved preference
if (localStorage.getItem("darkMode") === "true") {
  document.body.classList.add("dark-mode");
}

// ---------- IMAGE SLIDER ----------
const images = ["images/img1.jpg", "images/img2.jpg", "images/img3.jpg"];
let currentIndex = 0;

const sliderImage = document.getElementById("sliderImage");
const prevBtn = document.getElementById("prevBtn");
const nextBtn = document.getElementById("nextBtn");

function updateSlider() {
  sliderImage.src = images[currentIndex];
}

prevBtn.addEventListener("click", () => {
  currentIndex = (currentIndex - 1 + images.length) % images.length;
  updateSlider();
});

nextBtn.addEventListener("click", () => {
  currentIndex = (currentIndex + 1) % images.length;
  updateSlider();
});

// ---------- TO-DO LIST ----------
const todoInput = document.getElementById("todoInput");
const todoList = document.getElementById("todoList");
const addTodoBtn = document.getElementById("addTodoBtn");

function addTodo() {
  const value = todoInput.value.trim();
  if (!value) return;

  const li = document.createElement("li");
  li.textContent = value;

  const removeBtn = document.createElement("button");
  removeBtn.textContent = "X";
  removeBtn.style.marginLeft = "10px";

  removeBtn.addEventListener("click", () => li.remove());

  li.appendChild(removeBtn);
  todoList.appendChild(li);

  todoInput.value = "";
}

addTodoBtn.addEventListener("click", addTodo);

// ---------- FORM VALIDATION ----------
const contactForm = document.getElementById("contactForm");

contactForm.addEventListener("submit", function (event) {
  event.preventDefault();

  const email = document.getElementById("email").value.trim();
  const message = document.getElementById("message").value.trim();

  if (!email.includes("@")) {
    showMessage("Please enter a valid email.", "error");
    return;
  }

  if (message.length < 10) {
    showMessage("Message must be at least 10 characters.", "error");
    return;
  }

  showMessage("Message sent successfully!", "success");
  contactForm.reset();
});